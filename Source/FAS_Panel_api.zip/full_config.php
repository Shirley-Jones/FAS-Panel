<?php
/*
	此文件用于进行扩展配置
	
	数组会自动识别为单选，字符串会自动识别为编辑框
*/
	$config["Feedback"] = [];
	
	$config["Feedback"]["Field"]["网速？"] = ["很好","一般","很差"];
	$config["Feedback"]["Field"]["您用来？(请输入)"] = "";
	$config["Feedback"]["Field"]["稳定性？"] = ["很好","一般","很差"];
	$config["Feedback"]["Field"]["总体评价"] = ["很好","一般","无Fuck说"];